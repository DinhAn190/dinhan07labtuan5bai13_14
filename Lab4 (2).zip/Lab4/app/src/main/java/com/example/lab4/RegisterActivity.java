package com.example.lab4;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText edtEmail, edtPassword, edtConfirm;
    TextView tvRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edtEmail = findViewById(R.id.edtRegEmail);
        edtPassword = findViewById(R.id.edtRegPassword);
        edtConfirm = findViewById(R.id.edtRegConfirmPassword);
        tvRegister = findViewById(R.id.tvRegister);

        tvRegister.setOnClickListener(v -> {

            String email = edtEmail.getText().toString();
            String pass = edtPassword.getText().toString();
            String confirm = edtConfirm.getText().toString();

            if(email.isEmpty() || pass.isEmpty() || confirm.isEmpty()){
                Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                return;
            }

            if(!pass.equals(confirm)){
                Toast.makeText(this, "Mật khẩu không khớp!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Lưu SharedPreferences
            SharedPreferences preferences = getSharedPreferences("USER_DATA", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();

            editor.putString("email", email);
            editor.putString("password", pass);
            editor.apply();

            Toast.makeText(this, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();

            // Quay lại Login
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            finish();
        });
    }
}
