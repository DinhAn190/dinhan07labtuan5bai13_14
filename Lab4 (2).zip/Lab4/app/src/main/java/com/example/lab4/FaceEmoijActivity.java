package com.example.lab4;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class FaceEmoijActivity extends AppCompatActivity {

    private int[] EMOJI_IDS = {
            R.id.iv_face1, R.id.iv_face2, R.id.iv_face3,
            R.id.iv_face4, R.id.iv_face5, R.id.iv_face6,
            R.id.iv_face7, R.id.iv_face8, R.id.iv_face9
    };

    private int[] EMOJI_DRAWABLES = {
            R.drawable.ic_angry, R.drawable.ic_baffle, R.drawable.ic_beauty,
            R.drawable.ic_boss, R.drawable.ic_choler, R.drawable.ic_dribble,
            R.drawable.ic_look_down, R.drawable.ic_sure, R.drawable.ic_tire, R.drawable.ic_smile
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face_emoij);

        for (int id : EMOJI_IDS) {
            ImageView iv = findViewById(id);
            iv.setOnClickListener(v -> {
                Drawable drawable = ((ImageView)v).getDrawable();
                Toast toast = new Toast(this);
                ImageView ivToast = new ImageView(this);
                ivToast.setImageDrawable(drawable);
                toast.setView(ivToast);
                toast.setDuration(Toast.LENGTH_SHORT);
                toast.show();
            });
        }

        Button btnRandom = findViewById(R.id.btnRandom);
        btnRandom.setOnClickListener(v -> randomEmojis());
    }

    private void randomEmojis() {
        Random rand = new Random();
        for (int id : EMOJI_IDS) {
            int index = rand.nextInt(EMOJI_DRAWABLES.length);
            ((ImageView)findViewById(id)).setImageResource(EMOJI_DRAWABLES[index]);
        }
    }
}
