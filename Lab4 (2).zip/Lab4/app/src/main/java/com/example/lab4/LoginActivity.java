package com.example.lab4;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    EditText edtEmail, edtPassword;
    TextView tvLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        tvLogin = findViewById(R.id.tvLogin);
        TextView tvGoRegister = findViewById(R.id.tvGoRegister);
        tvGoRegister.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });

        tvLogin.setOnClickListener(v -> {
            String email = edtEmail.getText().toString();
            String pass = edtPassword.getText().toString();
            android.util.Log.d("PREF_DATA", "Email: " + email);
            android.util.Log.d("PREF_DATA", "Password: " + pass);

            SharedPreferences pref = getSharedPreferences("USER_DATA", MODE_PRIVATE);
            String savedEmail = pref.getString("email", "");
            String savedPass = pref.getString("password", "");

            if (!email.equals(savedEmail) || !pass.equals(savedPass)) {
                Toast.makeText(this, "Sai email hoặc mật khẩu!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Custom Toast
            View layout = LayoutInflater.from(this).inflate(R.layout.toast_layout, findViewById(android.R.id.content), false);
            TextView tvToastText = layout.findViewById(R.id.tvToastText);
            tvToastText.setText("Đăng nhập thành công!");

            Toast toast = new Toast(this);
            toast.setView(layout);
            toast.setDuration(Toast.LENGTH_LONG);
            toast.show();

            startActivity(new Intent(LoginActivity.this, MenuActivity.class));
        });

    }
}
